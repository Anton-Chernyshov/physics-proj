import matplotlib.pyplot as plt
import pandas as pd
import os
import math

# === CONFIG ===
directory = "trimmedruns"
files = sorted([f for f in os.listdir(directory) if f.startswith("run") and f.endswith(".csv")])
num_files = len(files)

# === FIGURE SETUP ===
cols = 5
rows = math.ceil(num_files / cols)
fig, axes = plt.subplots(rows, cols, figsize=(cols * 4, rows * 3), sharex=False, sharey=False)
axes = axes.flatten()

# === PLOT EACH FILE ===
for i, filename in enumerate(files):
    df = pd.read_csv(os.path.join(directory, filename))

    try:
        time_col = next(c for c in df.columns if "Time" in c and "(s)" in c)
        force_col = next(c for c in df.columns if "Sensor" in c)

        axes[i].plot(df[time_col], df[force_col])
        axes[i].set_title(filename.replace(".csv", ""))
        axes[i].set_xlabel("Time (s)")
        axes[i].set_ylabel("Force (N)")
    except Exception as e:
        axes[i].text(0.5, 0.5, "Error", ha='center', va='center')
        print(f"Error plotting {filename}: {e}")

# === HIDE UNUSED SUBPLOTS ===
for j in range(i+1, len(axes)):
    fig.delaxes(axes[j])

plt.tight_layout()
plt.show()
