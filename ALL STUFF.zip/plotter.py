import pandas as pd
import matplotlib.pyplot as plt

# === CONFIG ===
run_number = 2 
runcount = 2
input_file = f"separated_runs{runcount}/run{run_number}.csv"

# === LOAD DATA ===
df = pd.read_csv(input_file)

# === PLOT ===
plt.figure(figsize=(8, 5))
plt.plot(df["Time (s)"], df["Sensor"], label=f"Run {run_number}", color="blue")
plt.xlabel("Time (s)")
plt.ylabel("Sensor Reading")
plt.title(f"Sensor vs Time for Run {run_number}")
plt.grid(True)
plt.legend()
plt.tight_layout()
plt.show()
