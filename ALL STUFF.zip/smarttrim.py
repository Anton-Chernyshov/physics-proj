import pandas as pd
import numpy as np
import os

# === CONFIG ===
directory = "trimmedruns"
buffer_points = 20      # Number of points to leave before and after the active region
threshold_factor = 3.0  # How many std devs above baseline to consider "active"

for filename in sorted(os.listdir(directory)):
    if not filename.endswith(".csv"):
        continue

    path = os.path.join(directory, filename)
    df = pd.read_csv(path)

    try:
        time_col = next(c for c in df.columns if "Time" in c and "(s)" in c)
        force_col = next(c for c in df.columns if "Sensor" in c)
    except StopIteration:
        print(f"Skipping {filename}: missing expected columns")
        continue

    force = df[force_col].values

    # === Estimate baseline from the first 10% of data
    sample_size = max(10, int(0.1 * len(force)))
    baseline_segment = force[:sample_size]
    baseline_mean = np.mean(baseline_segment)
    baseline_std = np.std(baseline_segment)

    # === Set dynamic threshold
    threshold = baseline_mean + threshold_factor * baseline_std

    # === Find active region (indices where force exceeds threshold)
    active_indices = np.where(force > threshold)[0]

    if len(active_indices) == 0:
        print(f"{filename}: no signal detected")
        continue

    start_idx = max(active_indices[0] - buffer_points, 0)
    end_idx = min(active_indices[-1] + buffer_points, len(force) - 1)

    trimmed_df = df.iloc[start_idx:end_idx + 1]
    trimmed_df.to_csv(path, index=False)
    print(f"Trimmed {filename}: rows {start_idx}-{end_idx} (out of {len(df)})")
