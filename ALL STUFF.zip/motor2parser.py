import pandas as pd
import os

# === CONFIG ===
input_file = "motor2.csv"  # Change to your file name
output_dir = "separated_runs2"
os.makedirs(output_dir, exist_ok=True)

# === LOAD FILE ===
df = pd.read_csv(input_file)

# === PARSE HEADERS ===
run_columns = {}
for col in df.columns:
    if "Run" in col:
        run_id = col.split("Run")[1].strip()
        if run_id not in run_columns:
            run_columns[run_id] = []
        run_columns[run_id].append(col)

# === EXTRACT AND SAVE ===
for run_id, columns in run_columns.items():
    run_df = df[columns].copy()
    
    # Clean column names
    new_columns = [col.split("Run")[0].strip() for col in columns]
    run_df.columns = new_columns

    # Optional: Try to convert numeric columns
    for col in run_df.columns:
        try:
            run_df[col] = pd.to_numeric(run_df[col])
        except Exception:
            pass


    output_path = os.path.join(output_dir, f"run{run_id}.csv")
    run_df.to_csv(output_path, index=False)
    print(f"Saved: run{run_id}.csv")
