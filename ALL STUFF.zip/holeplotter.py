import matplotlib.pyplot as plt

# Hole sizes and average forces
hole_sizes = [3.5, 4.0, 4.5, 5.0, 5.5, 6.0]
average_forces = [11.79, 8.20, 5.07, 4.52, 2.55, 1.51]

# Create the plot
plt.figure(figsize=(8, 5))
plt.plot(hole_sizes, average_forces, marker='o', linestyle='-', color='royalblue')
plt.title('Average Peak Force vs Hole Size')
plt.xlabel('Hole Size (mm)')
plt.ylabel('Average Peak Force (N)')
plt.grid(True)
plt.tight_layout()
plt.show()
