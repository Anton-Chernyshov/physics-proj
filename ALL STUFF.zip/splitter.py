import pandas as pd
import os

# === CONFIG ===
input_file = "motor2.csv"  
output_dir = "separated_runs2"  
os.makedirs(output_dir, exist_ok=True)

# === LOAD CSV ===
df = pd.read_csv(input_file, header=None)

# First row contains column names
header = df.iloc[0]
df = df[1:]
df.columns = header
df.reset_index(drop=True, inplace=True)

# Determine number of runs (assuming every 3 columns = 1 run)
num_cols = df.shape[1]
run_indices = range(0, num_cols, 3)

# === EXTRACT AND SAVE ===
for idx, start_col in enumerate(run_indices):
    run_num = idx + 1
    try:
        label_col = df.columns[start_col]
        time_col = df.columns[start_col + 1]
        data_col = df.columns[start_col + 2]

        time_data = pd.to_numeric(df[time_col], errors='coerce')
        sensor_data = pd.to_numeric(df[data_col], errors='coerce')

        run_df = pd.DataFrame({
            "Time (s)": time_data,
            "Sensor": sensor_data
        })

        run_df.dropna(inplace=True)
        run_df.to_csv(os.path.join(output_dir, f"run{run_num}.csv"), index=False)
        print(f"Saved run{run_num}.csv")
    except Exception as e:
        print(f"Skipping Run {run_num}: {e}")
