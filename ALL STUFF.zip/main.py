import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("motor1.csv", header=None)

header = df.iloc[0]
df = df[1:]
df.columns = header
df.reset_index(drop=True, inplace=True)
num_cols = df.shape[1]
run_cols = [i for i in range(0, num_cols, 3)]
num_runs = len(run_cols)

# Plot each run
plt.figure(figsize=(10, 6))
for i in run_cols:
    time_col = df.columns[i + 1]
    force_col = df.columns[i + 2]

    try:
        time_data = pd.to_numeric(df[time_col], errors='coerce')
        force_data = pd.to_numeric(df[force_col], errors='coerce')
        plt.plot(time_data, force_data, label=f"Run {(i // 3) + 1}")
    except Exception as e:
        print(f"Skipping run {(i // 3) + 1}: {e}")

plt.xlabel("Time (s)")
plt.ylabel("Force (N)")
plt.title("SparkVue Force vs Time")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()
