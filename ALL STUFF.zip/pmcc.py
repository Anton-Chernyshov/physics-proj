import numpy as np
from scipy.stats import pearsonr
import matplotlib.pyplot as plt

# My data
hole_sizes = np.array([3.5, 4.0, 4.5, 5.0, 5.5, 6.0])
average_forces = np.array([11.79, 8.20, 5.07, 4.52, 2.55, 1.51])

log_forces = np.log(average_forces)

# Calculate PMCC between hole size and ln(force)
pmcc, p_value = pearsonr(hole_sizes, log_forces)

# Fit an exponential curve
coeffs = np.polyfit(hole_sizes, log_forces, 1)  # fit to ln(y) = mx + c
b, ln_a = coeffs
a = np.exp(ln_a)

# Generate fitted curve
x_fit = np.linspace(min(hole_sizes), max(hole_sizes), 100)
y_fit = a * np.exp(b * x_fit)

# Output
print(f"PMCC (linearised): {pmcc:.4f}")
print(f"Exponential model: y = {a:.3f} * e^({b:.3f}x)")

# Optional plot
plt.scatter(hole_sizes, average_forces, label='Data')
plt.plot(x_fit, y_fit, color='red', label='Exponential Fit')
plt.xlabel('Hole Size')
plt.ylabel('Average Force')
plt.legend()
plt.title('Exponential Fit to Data')
plt.grid(True)
plt.show()
