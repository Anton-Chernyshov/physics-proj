import pandas as pd
import os

# === CONFIG ===
directory = "allruns"
max_forces = {}

# === PROCESS EACH FILE ===
for filename in sorted(os.listdir(directory)):
    if filename.startswith("run") and filename.endswith(".csv"):
        path = os.path.join(directory, filename)
        df = pd.read_csv(path)

        try:
            force_col = next(col for col in df.columns if "Sensor" in col)
            max_force = df[force_col].max()
            max_forces[filename] = max_force
        except Exception as e:
            print(f"Skipping {filename}: {e}")

# === DISPLAY RESULTS ===
print("\nMax Force (N) per Run:")
for filename, max_force in max_forces.items():
    print(f"{filename}: {max_force:.2f} N")
