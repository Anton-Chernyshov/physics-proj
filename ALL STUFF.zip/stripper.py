import pandas as pd
import os

# === CONFIG ===
directory = "separated_runs2"

# === PROCESS EACH FILE ===
for filename in os.listdir(directory):
    if filename.startswith("run") and filename.endswith(".csv"):
        path = os.path.join(directory, filename)
        df = pd.read_csv(path)

        # Try to find "Time (s)" and "Force (N)" columns
        try:
            time_col = next(col for col in df.columns if "Time" in col and "(s)" in col)
            force_col = next(col for col in df.columns if "Force" in col and "(N)" in col)
        except StopIteration:
            print(f"Skipping {filename}: Required columns not found.")
            continue

        # Strip to only these columns
        stripped_df = df[[time_col, force_col]].copy()
        stripped_df.columns = ["Time (s)", "Force (N)"]  # Normalize column names

        # Overwrite file
        stripped_df.to_csv(path, index=False)
        print(f"Stripped: {filename}")
